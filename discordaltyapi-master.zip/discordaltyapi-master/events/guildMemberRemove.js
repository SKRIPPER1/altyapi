module.exports = member => {
  let guild = member.guild;
  member.send('Keşke Gitmeseydiniz Oysaki Çok Seveceğinizi Düşünüyordum!');
};
