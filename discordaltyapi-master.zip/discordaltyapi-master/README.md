# MO1RA BOT ALTYAPI
#BU ALT YAPI TERBİYESİZ TARAFINDAN YAPILMIŞTIR!

Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `Terbiyesiz'e Aittir`. Bot Altyapısını Sizlerin Kullanması İçin Verdik Gerekli Modüller Yüklüdür..!

[Resmi Discord Sunucumuz](https://discord.gg/CHp4n28)

[Resmi Youtube Kanalımız](https://www.youtube.com/channel/UC5mxQbR-4er2giWDTq9SgQg/videos?view_as=subscriber)

[Discord Kişisel Hesabım] Terbiyesizamauslu#1438


-------------------

`İyi Kodlamalar ay iyi düzeltmeler`
